public interface ICanli {
    String getIsim();
    String getKonus();
}
