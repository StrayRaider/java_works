public class At extends Hayvan{

    At(String Isim){
        super(Isim);
        }

    @Override
    public String getKonus() {
        // TODO Auto-generated method stub
        return "ben bir atim";
        
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return this.getIsim()+" + "+this.getKonus();
    }
    
}
